£0 CHALLENGE — INSTALLABLE WEB APP

This package is a PWA-ready version of the game.

IMPORTANT:
The game files need to be hosted at an HTTPS web address before Safari can install
them as a Home Screen web app. This chat can create the complete package but does
not provide a permanent public HTTPS hosting address.

Once hosted:
1. Open the HTTPS address in Safari on iPhone.
2. Tap Share.
3. Tap Add to Home Screen.
4. Turn on Open as Web App.
5. Tap Add.

The game saves progress locally on the device/browser and works offline after its
assets have been cached.
